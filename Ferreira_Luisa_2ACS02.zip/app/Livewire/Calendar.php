<?php

namespace App\Livewire;

use Carbon\Carbon;
use Livewire\Component;

class Calendar extends Component
{
    public $currentDate;
    public $selectedDay;

    public function mount()
    {
        $this->currentDate = Carbon::now();
    }

    public function changeMonth($direction)
    {
        $this->currentDate = $direction === 'prev'
            ? $this->currentDate->subMonth()
            : $this->currentDate->addMonth();
    }

    public function selectDay($day)
    {
        $this->selectedDay = $this->currentDate->format('Y-m') . '-' . $day;
        $this->dispatch('daySelected', ['selectedDay' => $this->selectedDay]);
    }

    public function render()
    {
        $daysInMonth = $this->currentDate->daysInMonth;
        return view('livewire.calendar', compact('daysInMonth'))->layout('layouts.app');
    }

}
