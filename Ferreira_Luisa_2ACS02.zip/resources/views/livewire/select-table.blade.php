<div>
    @if ($selectedDay && $selectedHour && $peopleCount)
        <div class="fixed inset-0 bg-gray-500 bg-opacity-50 flex items-center justify-center">
            <div class="bg-white p-4 rounded shadow-lg max-w-md w-full">
                <h2 class="text-lg font-bold mb-2">
                    Available Tables In {{ date('d/m/Y', strtotime($selectedDay)) }} At {{ $selectedHour }} For {{ $peopleCount }} people
                </h2>


                <div class="grid grid-cols-3 gap-4">
                    @foreach ($tables as $table)
                        <div
                            class="p-4 text-center rounded cursor-pointer
                                {{ $table['occupied'] ? 'bg-red-500 text-white' : 'bg-green-500 text-white' }}"
                            wire:click="selectTable({{ $table['id'] }})"
                        >
                            {{ $table['name'] }}
                        </div>
                    @endforeach
                </div>

                <button
                    class="mt-4 px-4 py-2 bg-green-500 text-white rounded"
                    wire:click="createReservation"
                >
                    Submit The Reservation
                </button>

                <button
                    class="mt-4 px-4 py-2 bg-gray-500 text-white rounded"
                    wire:click="closePopup"
                >
                    Close
                </button>

                @if (session()->has('message'))
                    <p class="text-green-500 mt-2">{{ session('message') }}</p>
                @endif
                @if (session()->has('error'))
                    <p class="text-red-500 mt-2">{{ session('error') }}</p>
                @endif
            </div>
        </div>
    @endif
</div>
