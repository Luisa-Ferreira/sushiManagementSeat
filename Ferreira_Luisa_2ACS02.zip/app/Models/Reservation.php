<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Reservation extends Model
{
    protected $table = 'reservations';

    protected $fillable = [
        'user_id',
        'table_id',
        'reservation_date',
        'reservation_time',
        'num_people',
    ];

    // Os campos que devem ser convertidos para tipos específicos
    protected $casts = [
        'reservation_date' => 'date',
        'reservation_time' => 'string'
    ];

    // Relacionamento com o modelo User (uma reserva pertence a um usuário)


    public function user()
    {
        return $this->belongsTo(User::class); // 'user_id' é a chave estrangeira
    }

    // Relacionamento com o modelo Table (uma reserva pertence a uma mesa)
    public function table()
    {
        return $this->belongsTo(Table::class); // 'table_id' é a chave estrangeira
    }
}
