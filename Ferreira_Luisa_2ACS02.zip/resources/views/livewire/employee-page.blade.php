<div class=" p-6">
    @if ($view === 'details')
        <div class="flex-1 bg-[rgb(253,241,225)] text-[rgb(196,151,109)] p-6">
            <div class="px-6 rounded-lg w-3/4 mx-auto">
                <h2 class="text-2xl font-bold mb-2">{{ $selectedReservation->user_id }}</h2>
                <!-- Mostra o e-mail do usuário -->
                <p class="text-sm text-gray-700">Table: {{ $selectedReservation->table_id }}</p>
                <p class="text-sm text-gray-700">Number of People: {{ $selectedReservation->num_people }}</p>
                <p class="text-sm text-gray-700">Reservation Date: {{ $selectedReservation->reservation_date }}</p>
                <p class="text-sm text-gray-700">Reservation Time: {{ $selectedReservation->reservation_time }}</p>
            </div>
        </div>
    @endif


    @if ($view === 'list')
        <h2 class="text-xl  font-bold mb-4">All Reservations</h2>

        <ul class="space-y-4 overflow-auto max-h-[70vh] px-2">
            @foreach ($reservations as $reservation)
                <li class="py-3 px-4 border-b border-gray-600 bg-gray-700 rounded-lg">
                    <div class="flex justify-between items-center">
                        <!-- Informações do Usuário -->
                        <div class="w-2/3 truncate">
                            <a href="#" wire:click.prevent="showReservationDetails({{ $reservation->id }})"
                               class="font-bold text-lg text-white">
                                {{ $reservation->user->name }}
                            </a>
                            <p class="text-sm text-gray-300">{{ $reservation->table->name }}</p>
                        </div>

                        <div x-data="{ showRemoveModal: false }">
                            <a href="#" @click="showRemoveModal = true" class="text-red-500 hover:underline">Remove User</a>

                            <div x-show="showRemoveModal" x-transition.opacity class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
                                <div class="bg-white p-6 rounded shadow-lg w-1/3">
                                    <h2 class="text-2xl font-bold mb-4">Delete Confirmation</h2>
                                    <p class="mb-6">Do you really want to delete this user?</p>
                                    <div class="flex justify-end space-x-4">
                                        <button @click="showRemoveModal = false; $wire.set('view', 'list')" class="px-4 py-2 bg-gray-500 text-white rounded">Cancel</button>
                                        <button @click="showRemoveModal = false; $wire.deleteReservation({{ $reservation->id }})" class="px-4 py-2 bg-red-500 text-white rounded">Remove</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
            @endforeach
        </ul>
    @endif
</div>
