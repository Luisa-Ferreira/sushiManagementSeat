<?php

namespace App\Livewire;

use Carbon\Carbon;
use Livewire\Component;

class NowReservations extends Component
{
    public $currentDay;
    public $currentHour;
    public $peopleCount;
    public $tables = [];

    public function mount()
    {
        // Inicializa o dia atual
        $this->currentDay = now()->format('Y-m-d');

        // Ajusta a hora atual para o próximo intervalo válido
        $minute = now()->minute;
        $hour = now()->hour;

        if ($minute > 30) {
            $this->currentHour = sprintf('%02d:00', $hour + 1);
        } else {
            $this->currentHour = sprintf('%02d:30', $hour);
        }

        $this->peopleCount = 1; // Inicializa com uma pessoa
    }

    public function updatedPeopleCount()
    {
        if ($this->peopleCount < 1) {
            $this->peopleCount = 1; // Garante que o número de pessoas seja pelo menos 1
        }
    }


    public function render()
    {
        return view('livewire.now-reservations', [
            'currentDay' => $this->currentDay,
            'currentHour' => $this->currentHour,
        ])->layout('layouts.app');
    }
}
