<?php

namespace App\Livewire;

use App\Models\User;
use Livewire\Component;


class UserPanel extends Component
{
    public $view = 'list';
    public $users = [];
    public $search = '';
    public $filterRole = '';
    public $selectedUser;
    public $name,$email,$phone,$password,$role;

    protected $listeners = ['resetUserPanel','showAddUserForm', 'showUserDetails' ];

    protected $rules = [
        'name' => 'required|regex:/^[a-zA-Z\s]+(\.[a-zA-Z\s]+)*\.?$/|unique:users,name',
        'email' => 'required|email|unique:users,email',
        'phone' => 'required|regex:/^[0-9+\-]+$/|unique:users,phone',
        'password' => 'required|min:6|regex:/^(?=.*[A-Z]).+$/',
        'role' => 'required|in:manager,employee,client',
    ];

    protected $messages = [
        'name.required' => 'The Name field is required.',
        'name.regex' => 'The Name must only contain letters and spaces.',
        'name.unique' => 'The Name is already taken. Please choose another.',
        'email.required' => 'The Email field is required.',
        'email.email' => 'Please enter a valid email address.',
        'email.unique' => 'The Email is already registered. Please use a different email.',
        'phone.required' => 'The Phone field is required.',
        'phone.regex' => 'The Phone must only contain numbers, "+", or "-".',
        'phone.unique' => 'The Phone number is already in use. Please use a different number.',
        'password.required' => 'The Password is required.',
        'password.min' => 'The Password must be at least 6 characters long.',
        'password.regex' => 'The Password must contain at least one uppercase letter.',
        'role.required' => 'The Role field is required.',
        'role.in' => 'The Role must be either Manager, Employee, or Client.',
    ];

    public function updatedSearch()
    {
        $this->filterUsers();
    }

    // Add updatedFilterRole method to handle role filter updates
    public function updatedFilterRole()
    {
        $this->filterUsers();
    }

    public function filterUsers()
    {
        $query = User::query();

        // Apply search filter if search term exists
        if (!empty($this->search)) {
            $searchTerm = '%' . $this->search . '%';
            $query->where(function($q) use ($searchTerm) {
                $q->where('name', 'like', $searchTerm)
                    ->orWhere('email', 'like', $searchTerm)
                    ->orWhere('phone', 'like', $searchTerm);
            });
        }

        // Apply role filter if role is selected
        if (!empty($this->filterRole)) {
            $query->where('role', $this->filterRole);
        }

        $this->users = $query->get();
    }
    public function showAddUserForm()
    {
        //to reset the previus data insert
        $this->resetFields();
        $this->view = 'add';
    }
    public function addUser()
    {
        // Valida os dados do formulário
        $this->validate();

        // Cria um novo usuário
        User::create([
            'name' => $this->name,
            'email' => $this->email,
            'phone' => $this->phone,
            'password' => bcrypt($this->password), // Hash da senha
            'role' => $this->role,
        ]);

        $this->users = User::all();

        // Reseta os campos e retorna para a view "list"
        $this->resetFields();
        // Exibe uma mensagem de sucesso
        $this->view = 'list';

        $this->dispatch('add-user-modal');

        session()->flash('message', 'User added successfully!');

    }
    public function fillUserDetails($id)
    {
        $this->selectedUser = User::find($id);

        // Preencha as propriedades com os valores do usuário selecionado
        $this->name = $this->selectedUser->name;
        $this->email = $this->selectedUser->email;
        $this->phone = $this->selectedUser->phone;
        $this->password = ''; // Não carregar a senha para segurança
        $this->role = $this->selectedUser->role;


        $this->view = 'edit'; // Exibe o formulário de edição
    }
    public function showUserDetails($id)
    {
        $this->selectedUser = User::find($id);

        // Verifica se o usuário foi encontrado antes de acessar suas propriedades
        if ($this->selectedUser) {
            $this->name = $this->selectedUser->name;
            $this->email = $this->selectedUser->email;
            $this->phone = $this->selectedUser->phone;

            $this->view = 'details'; // Exibe os detalhes do usuário
        } else {
            session()->flash('error', 'User not found.');
        }
    }

    public function updateUser()
    {
        // Valida os dados do formulário
        $this->validate([
            'name' => 'required|regex:/^[a-zA-Z0-9\s]+(\.[a-zA-Z0-9\s]+)*\.?$/|unique:users,name,' . $this->selectedUser->id,
            'email' => 'required|email|unique:users,email,' . $this->selectedUser->id,
            'phone' => 'required|regex:/^[0-9+\-]+$/|unique:users,phone,' . $this->selectedUser->id,
            'password' => 'nullable|min:6|regex:/^(?=.*[A-Z]).+$/',
            'role' => 'required|in:manager,employee,client',
        ]);

        $updateData = [
            'name' => $this->name,
            'email' => $this->email,
            'phone' => $this->phone,
            'role' => $this->role,
        ];

        //stay with the previous one
        if (!empty($this->password)) {
            $updateData['password'] = bcrypt($this->password);
        }

        $this->selectedUser->update($updateData);



        // Atualiza a lista de usuários
        $this->users = User::all();

        // Dispara o modal de sucesso
        $this->dispatch('edit-user-modal');

        // Volta para a view "list"
        $this->view = 'list';
    }


    public function resetFields()
    {
        $this->name = '';
        $this->email = '';
        $this->phone = '';
        $this->password = '';
        $this->role = '';
        $this->selectedUser = null;
    }

    public function resetUserPanel()
    {
        logger("setActiveSection called with:");

        // Redefine para a lista de usuários
        $this->resetFields();
        return redirect()->route('users'); // Limpa os campos, se necessário
    }
    public function setActiveSection($section)
    {
        logger("setActiveSection called with: $section");
        $this->activeSection = $section;

        // Se a seção selecionada for "users", redefina o estado do componente de usuários
        if ($section === 'users') {
            $this->emitTo('user-panel','resetUserPanel'); // Emitir evento para o componente UserPanel
        }
    }

    public function deleteUser($id)
    {
        User::find($id)->delete();
        $this->users = User::all();
    }

    public function mount()
    {
        $this->filterUsers();// Carrega todos os usuários ao iniciar
    }

    public function render()
    {
        return view('livewire.user-panel', ['users' => $this->users])->layout('layouts.admin');
    }
}
