<?php

namespace App\Livewire;

use App\Models\Reservation;
use App\Models\Table;
use App\Models\User;
use Livewire\Component;

class EmployeePage extends Component
{
    public $view = 'list';
    public $reservations = [];
    public $selectedReservation;
    public $users = [];
    public $tables = [];
    public $user_id,$table_id,$num_people,$reservation_date,$reservation_time;
    protected $listeners = ['resetReservationPanel', 'showReservationDetails' ];

    public function resetFields()
    {
        $this->user_id = '';
        $this->table_id = '';
        $this->num_people = '';
        $this->reservation_date = '';
        $this->reservation_time = '';

        $this->selectedReservation = null;
    }

    public function showReservationDetails($id)
    {
        $this->selectedReservation = Reservation::find($id);

        // Verifica se o usuário foi encontrado antes de acessar suas propriedades
        if ($this->selectedReservation) {
            $this->user_id = $this->selectedReservation->user_id;
            $this->table_id = $this->selectedReservation->table_id;
            $this->num_people = $this->selectedReservation->num_people;
            $this->reservation_date = $this->selectedReservation->reservation_date;
            $this->reservation_time = $this->selectedReservation->reservation_time;

            $this->view = 'details'; // Exibe os detalhes do usuário
        } else {
            session()->flash('error', 'Table not found.');
        }
    }

    public function showAddReservationForm()
    {
        //to reset the previus data insert
        $this->resetFields();
    }

    public function deleteReservation($id)
    {
        Reservation::find($id)->delete();
        $this->reservations = Reservation::all();
    }

    public function fillReservationDetails($id)
    {
        $this->selectedReservation = Reservation::find($id);

        // Preencha as propriedades com os valores do usuário selecionado
        $this->user_id = $this->selectedReservation->user_id;
        $this->table_id = $this->selectedReservation->table_id;
        $this->num_people = $this->selectedReservation->num_people;
        $this->reservation_date = $this->selectedReservation->reservation_date;
        $this->reservation_time = $this->selectedReservation->reservation_time;

        $this->users = User::all();
        $this->tables = Table::all();

        $this->view = 'edit'; // Exibe o formulário de edição
    }

    public function mount()
    {
        $this->users = User::all(); // Carrega todos os usuários
        $this->tables = Table::all();
        $this->reservations = Reservation::all();
    }

    public function render()
    {
        return view('livewire.employee-page')->layout('layouts.app');
    }
}
