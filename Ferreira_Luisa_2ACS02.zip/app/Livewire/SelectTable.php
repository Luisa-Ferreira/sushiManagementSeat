<?php

namespace App\Livewire;

use App\Models\Reservation;
use Livewire\Component;
use App\Models\Table;

class SelectTable extends Component
{
    public $selectedDay,$selectedHour,$peopleCount,$selectedTable;
    public $tables = [];

    protected $listeners = ['showTablePopup'];

    public function showTablePopup($data)
    {
        $this->selectedDay = $data['day'];
        $this->selectedHour = $data['hour'];
        $this->peopleCount = $data['peopleCount'];

        // Carregar mesas disponíveis para o horário e dia selecionados
        $this->loadTables();
    }

    public function loadTables()
    {
        // Obtenha IDs de mesas reservadas no horário e dia selecionados
        $reservedTables = Reservation::where('reservation_date', $this->selectedDay)
            ->where('reservation_time', $this->selectedHour)
            ->pluck('table_id')
            ->toArray();

        // Carregar mesas com estado de ocupação
        $this->tables = Table::all()->map(function ($table) use ($reservedTables) {
            return [
                'id' => $table->id,
                'name' => $table->name,
                'occupied' => in_array($table->id, $reservedTables), // true se estiver reservada
            ];
        })->toArray();
    }

    public function createReservation()
    {
        // Validação básica
        if (!$this->selectedTable || !$this->selectedDay || !$this->selectedHour || !$this->peopleCount) {
            session()->flash('error', 'Por favor, selecione todos os dados.');
            return;
        }

        Reservation::create([
            'user_id' => auth()->id(),
            'table_id' => $this->selectedTable,
            'reservation_date' => $this->selectedDay,
            'reservation_time' => $this->selectedHour,
            'num_people' => $this->peopleCount,
        ]);

        session()->flash('message', 'Reserva criada com sucesso!');

        // Recarregar o estado das mesas
        $this->loadTables();

        // Fechar o pop-up
        $this->closePopup();
    }

    public function selectTable($tableId)
    {
        // Lógica para processar a seleção da mesa
        $this->selectedTable = $tableId;
    }

    public function selectPeople()
    {
        if ($this->peopleCount > 0) {
            $this->dispatch('showTablePopup', [
                'day' => $this->selectedDay,
                'hour' => $this->selectedHour,
                'peopleCount' => $this->peopleCount, // Incluímos o número de pessoas
            ]);

            $this->closePopup();
        }
    }

    public function closePopup()
    {
        $this->selectedDay = null;
        $this->selectedHour = null;
        $this->peopleCount = null;
        $this->selectedTable = null;
        $this->tables = [];
    }


    public function render()
    {
        return view('livewire.select-table');
    }
}
