<div class="p-4 bg-gray-100 rounded shadow">
    <h2 class="text-2xl font-bold mb-4">Reservations For Now</h2>

    <!-- Mesas Disponíveis -->
    <livewire:select-people
        :selectedDay="$currentDay"
        :selectedHour="$currentHour"
        :peopleCount="$peopleCount"
    />
    <livewire:select-table />
</div>

