<?php

namespace App\Livewire;

use Livewire\Component;

class FutureReservations extends Component
{
    public $selectedDate;

    public function selectDate($date)
    {
        $this->selectedDate = $date;
    }

    public function render()
    {
        return view('livewire.future-reservations')->layout('layouts.app');
    }
}
