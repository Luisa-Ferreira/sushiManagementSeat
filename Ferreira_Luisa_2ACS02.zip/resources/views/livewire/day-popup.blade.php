<div>
    @if ($selectedDay)
        <div
            class="fixed inset-0 bg-gray-500 bg-opacity-50 flex items-center justify-center"
            wire:keydown.escape="closePopup"
        >
            <div class="bg-white p-4 rounded shadow-lg max-w-sm w-full">
                <h2 class="text-lg font-bold mb-2">
                    Available Hours for {{ date('d/m/Y', strtotime($selectedDay)) }}
                </h2>

                <div class="max-h-60 overflow-y-auto">
                    @if (count($availableHours) > 0)
                        <ul class="space-y-2">
                            @foreach ($availableHours as $hour)
                                <li
                                    class="cursor-pointer p-2 bg-blue-100 rounded hover:bg-blue-200 mt-1"
                                    wire:click="selectHour('{{ $hour }}')"
                                >
                                    {{ $hour }}
                                </li>
                            @endforeach
                        </ul>
                    @else
                        <p class="text-red-500">No hours available for Sunday's. Day Off</p>
                    @endif
                </div>

                <button
                    class="mt-4 px-4 py-2 bg-gray-500 text-white rounded"
                    wire:click="closePopup"
                >
                    Close
                </button>
            </div>
        </div>
    @endif
</div>
