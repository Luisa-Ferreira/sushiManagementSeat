<footer class="py-10 bg-[rgb(196,151,109)] text-[rgb(253,241,225)]">
    <div class="container mx-auto">
        <!-- Parte Superior: Informações de Contato -->
        <div class="flex flex-wrap justify-between items-center mb-8">
            <!-- Informações de Contato -->
            <div class="w-full md:w-1/3 mb-4 md:mb-0">
                <h3 class="text-xl font-semibold mb-2">Contact Us</h3>
                <p class="text-sm">📞 Phone: +351 212 482 072 or +351 963 956 382 </p>
                <p class="text-sm">📧 Email: <a href="mailto:sushiawaycdo@gmail.com" class="underline hover:text-gray-300">sushiawaycdo@gmail.com</a></p>
                <p class="text-sm">📍 Address: R. 4 de Infantaria 8A, 1350-271 Lisboa, Portugal</p>
            </div>

            <!-- Horário -->
            <div class="w-full md:w-1/3 mb-4 md:mb-0 text-center">
                <h3 class="text-xl font-semibold mb-2">Opening Hours</h3>
                <p class="text-sm">Monday - Saturday: 12:30 - 10:00 and 18:00 - 22:00</p>
                <p class="text-sm">Sunday: Closed</p>
            </div>

            <!-- Redes Sociais -->
            <div class="w-full md:w-1/3 text-center md:text-right">
                <h3 class="text-xl font-semibold mb-2">Follow Us</h3>
                <div class="flex justify-center md:justify-end space-x-4">
                    <a href="https://www.instagram.com/sushiawaycdo?igsh=MWowMzM1OG85dDV2Zw==" class="text-xl hover:text-gray-300">
                        <i class="fab fa-instagram">Instagram: sushiawaycdo</i>
                    </a>
                </div>
            </div>
        </div>

        <!-- Parte Inferior: Direitos Autorais -->
        <div class="border-t border-gray-300 pt-4 text-center">
            <p class="text-sm">© 2024 SushiAway. All Rights Reserved.</p>
            <p class="text-sm">
                Website developed by Luisa Ferreira
            </p>
        </div>
    </div>
</footer>
