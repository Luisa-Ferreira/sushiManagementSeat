<div class="mb-6 flex flex-col space-y-4">
    <!-- Campo de busca -->
    <div>
        <input
            type="text"
            wire:model="search"
            placeholder="Search by name..."
            class="w-full px-4 py-2 border rounded bg-gray-700 text-white"
        />
    </div>

    <!-- Filtro por role -->
    <div>
        <select
            wire:model="role"
            class="w-full px-4 py-2 border rounded bg-gray-700 text-white"
        >
            <option value="">Filter by role...</option>
            @foreach ($roles as $role)
                <option value="{{ $role }}">{{ ucfirst($role) }}</option>
            @endforeach
        </select>
    </div>

    <!-- Resultados filtrados -->
    <ul class="space-y-4 overflow-auto max-h-[50vh]">
        @foreach ($users as $user)
            <li class="py-3 px-4 border-b border-gray-600 bg-gray-700 rounded-lg">
                <div class="flex justify-between items-center">
                    <div class="w-2/3 truncate">
                        <p class="font-bold text-lg text-white">{{ $user->name }}</p>
                        <p class="text-sm text-gray-300">{{ $user->role }}</p>
                    </div>
                </div>
            </li>
        @endforeach
    </ul>
</div>
