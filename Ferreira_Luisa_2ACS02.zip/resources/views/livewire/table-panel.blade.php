<div class="flex flex-col h-screen overflow-hidden">
    <!-- Lista de usuários -->
    @if ($view === 'details')
        <div class="flex-1 bg-[rgb(253,241,225)] text-[rgb(196,151,109)] p-6">
            <div class="px-6 rounded-lg w-3/4 mx-auto">
                <h2 class="text-2xl font-bold mb-2">{{ $selectedTable->name }}</h2>
                <!-- Mostra o e-mail do usuário -->
                <p class="text-sm text-gray-700">Occupied:
                    <span class="{{ $selectedTable->occupied ? 'text-red-500' : 'text-green-500' }} font-bold"> {{ $selectedTable->occupied ? 'Occupied' : 'Available' }}</span>
                </p>
                <p class="text-sm text-gray-700">Created at: {{ $selectedTable->created_at }}</p>
            </div>
        </div>
    @endif


    @if ($view === 'list')
        <h2 class="text-xl  font-bold mb-4">All Tables</h2>
        <h1 class="mb-6 text-lg">
            <a href="#" wire:click.prevent="showAddTableForm" class="text-[rgb(196,151,109)] hover:underline">+ Add Table</a>
        </h1>
        <ul class="space-y-4 overflow-auto max-h-[70vh] px-2">
            @foreach ($tables as $table)
                <li class="py-3 px-4 border-b border-gray-600 bg-gray-700 rounded-lg">
                    <div class="flex justify-between items-center">
                        <!-- Informações do Usuário -->
                        <div class="w-2/3 truncate">
                            <a href="#" wire:click.prevent="showTableDetails({{ $table->id }})" class="font-bold text-lg text-white">{{ $table->name }}</a>
                            <p class="text-sm text-gray-300">
                                <span class="{{ $table->occupied ? 'text-red-500' : 'text-green-500' }} font-bold"> {{ $table->occupied ? 'Occupied' : 'Available' }}</span>
                            </p>
                        </div>
                        <!-- Botões de Ação -->
                        <div class="flex space-x-4">
                            <a href="#" wire:click.prevent="fillTableDetails({{ $table->id }})" class="text-green-500 hover:underline">Change Table</a>
                            <a href="#" wire:click.prevent="deleteTable({{ $table->id }})" class="text-red-500 hover:underline">Remove Table</a>
                        </div>
                    </div>
                </li>
            @endforeach
        </ul>
    @endif

    <!-- Exibe o formulário para adicionar um novo usuário se a variável $view for 'add' -->
    @if ($view === 'add')


        <h2 class="text-xl font-bold mb-4">Add New Table</h2>

        <div x-data="{
            letter: @entangle('letter'),
            number: @entangle('number'),
            seats: @entangle('seats'),
            occupied: @entangle('occupied'),
            options: Array.from({ length: 99 }, (_, i) => (i + 1).toString().padStart(2, '0')),
            get name() {
                return this.letter && this.number ? `${this.letter}-${this.number}` : '';
            },
            submitForm() {
                $wire.set('letter', this.letter);
                $wire.set('number', this.number);
                $wire.set('seats', this.seats);
                $wire.set('occupied', this.occupied);
                $wire.saveTable(); // Chama o método Livewire para salvar
            },
        }">
            <form @submit.prevent="submitForm">
                <div class="mb-4">
                    <label class="block text-sm font-medium mb-2">Name</label>
                    <div class="flex space-x-2 items-center">
                        <!-- Dropdown para selecionar a letra -->
                        <select wire:model="letter" class="px-4 py-2 border rounded bg-gray-700 text-white">
                            <option value="">Select Letter</option>
                            @foreach (range('A', 'Z') as $char)
                                <option value="{{ $char }}">{{ $char }}</option>
                            @endforeach
                        </select>
                        <span class="text-white">-</span>
                        <!-- Dropdown para selecionar o número -->
                        <select wire:model="number" class="px-4 py-2 border rounded bg-gray-700 text-white">
                            <option value="">Select Number</option>
                            @for ($i = 1; $i <= 99; $i++)
                                <option value="{{ sprintf('%02d', $i) }}">{{ sprintf('%02d', $i) }}</option>
                            @endfor
                        </select>
                    </div>
                    @error('name')
                    <span class="text-red-500 text-sm">{{ $message }}</span>
                    @enderror
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium mb-2">Seats</label>
                    <input type="number" wire:model="seats" class="w-full px-4 py-2 border rounded bg-gray-700 text-white">
                    @error('seats') <span class="text-red-500 text-sm">{{ $message }}</span> @enderror
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-medium mb-2">Occupied</label>
                    <select wire:model="occupied"
                            class="w-full px-4 py-2 border rounded bg-gray-700 text-white">
                        <option value="">Occupied</option>
                        <option value="1">True</option>
                        <option value="0">False</option>
                    </select>
                    @error('occupied') <span class="text-red-500 text-sm">{{ $message }}</span> @enderror
                </div>

                <button type="submit" class="px-4 py-2 bg-blue-500 text-white rounded">Save Changes</button>
                <button type="button" wire:click.prevent="$set('view', 'list')" class="ml-2 px-4 py-2 bg-gray-500 text-white rounded">Cancel</button>
            </form>
        </div>
    @endif

    @if ($view === 'edit')
        <h2 class="text-xl font-bold mb-4 text-white">Edit Table</h2>
        <form wire:submit.prevent="updateTable">
            <!-- Name -->
            <div class="mb-4">
                <label class="block text-sm font-medium mb-2 text-white">Name</label>
                <div class="flex space-x-2 items-center">
                    <!-- Dropdown para selecionar a letra -->
                    <select wire:model="letter" class="px-4 py-2 border rounded bg-gray-700 text-white">
                        <option value="">Select Letter</option>
                        @foreach (range('A', 'Z') as $char)
                            <option value="{{ $char }}">{{ $char }}</option>
                        @endforeach
                    </select>

                    <span class="text-white">-</span>

                    <!-- Dropdown para selecionar o número -->
                    <select wire:model="number" class="px-4 py-2 border rounded bg-gray-700 text-white">
                        <option value="">Select Number</option>
                        @foreach (range(1, 99) as $num)
                            <option value="{{ str_pad($num, 2, '0', STR_PAD_LEFT) }}">
                                {{ str_pad($num, 2, '0', STR_PAD_LEFT) }}
                            </option>
                        @endforeach
                    </select>
                </div>
                @error('name') <span class="text-red-500 text-sm">{{ $message }}</span> @enderror
            </div>

            <!-- Seats -->
            <div class="mb-4">
                <label class="block text-sm font-medium mb-2 text-white">Seats</label>
                <input type="number" wire:model="seats" class="w-full px-4 py-2 border rounded bg-gray-700 text-white">
                @error('seats') <span class="text-red-500 text-sm">{{ $message }}</span> @enderror
            </div>

            <!-- Occupied -->
            <div class="mb-4">
                <label class="block text-sm font-medium mb-2 text-white">Occupied</label>
                <select wire:model="occupied" class="w-full px-4 py-2 border rounded bg-gray-700 text-white">
                    <option value="">Select Status</option>
                    <option value="1">Yes</option>
                    <option value="0">No</option>
                </select>
                @error('occupied') <span class="text-red-500 text-sm">{{ $message }}</span> @enderror
            </div>

            <!-- Save and Cancel Buttons -->
            <button type="submit" class="px-4 py-2 bg-blue-500 text-white rounded">Save Changes</button>
            <button type="button" wire:click.prevent="$set('view', 'list')" class="ml-2 px-4 py-2 bg-gray-500 text-white rounded">Cancel</button>
        </form>
    @endif

</div>
