<div class="bg-white p-4 rounded shadow-lg ">
    <!-- Navegação de Mês -->
    <div class="flex justify-between items-center mb-4 ">
        <button
            wire:click="changeMonth('prev')"
            class="px-4 py-2 bg-[rgb(196,151,109)] text-white rounded hover:bg-blue-600 focus:outline-none focus:ring">
            Previous
        </button>
        <div class="text-lg font-bold text-gray-700">
            {{ $currentDate->format('F Y') }}
        </div>
        <button
            wire:click="changeMonth('next')"
            class="px-4 py-2 bg-[rgb(196,151,109)] text-white rounded hover:bg-blue-600 focus:outline-none focus:ring">
            Next
        </button>
    </div>

    <!-- Cabeçalhos dos Dias da Semana -->
    <div class="grid grid-cols-7 gap-2 text-center font-semibold text-gray-600 mb-2">
        @foreach (['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'] as $day)
            <div class="uppercase">{{ $day }}</div>
        @endforeach
    </div>

    <!-- Dias do Calendário -->
    <div class="grid grid-cols-7 gap-1 text-center">
        @for ($i = 1; $i <= $daysInMonth; $i++)
            <div
                class="p-2 border rounded cursor-pointer
                    {{ $currentDate->format('Y-m-d') === $currentDate->copy()->day($i)->format('Y-m-d') ? 'bg-[rgb(196,151,109)] text-white' : 'bg-gray-100 hover:bg-gray-200' }}"
                wire:click="selectDay({{ $i }})">
                {{ $i }}
            </div>
        @endfor
    </div>
</div>
