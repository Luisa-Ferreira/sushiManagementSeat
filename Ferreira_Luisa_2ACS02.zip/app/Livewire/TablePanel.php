<?php

namespace App\Livewire;

use App\Models\Table;
use Livewire\Component;

class TablePanel extends Component
{
    public $view = 'list';
    public $tables = [];

    public $name,$seats,$occupied, $letter, $number;
    public $selectedTable;
    protected $listeners = ['resetTablePanel','showAddTableForm', 'showTableDetails' ];

    protected $rules = [
        'name' => 'required|regex:/^[A-Z]-\d{2}$/|unique:tables,name',
        'seats' => 'required|integer|min:1',
        'occupied' => 'required|boolean',
    ];

    protected $messages = [
        'name.required' => 'The Name field is required.',
        'name.regex' => 'The Name must start with a capital letter, followed by a dash "-", and two digits (e.g., A-01).',
        'seats.required' => 'The Seats field is required.',
        'seats.integer' => 'The Seats field must be a valid number.',
        'seats.min' => 'The Seats field must be at least 1.',
        'occupied.required' => 'The Occupied field is required.',
        'occupied.boolean' => 'The Occupied field must be true or false.',
    ];

    public function showAddTableForm()
    {
        //to reset the previus data insert
        $this->resetFields();
        $this->view = 'add';
    }
    public function addTable()
    {
        if ($this->letter && $this->number) {
            $this->name = $this->letter . '-' . sprintf('%02d', $this->number);
        } else {
            $this->addError('name', 'Both letter and number must be selected to generate the name.');
            return;
        }

        $this->validate();

        Table::create([
            'name' => $this->name,
            'seats' => $this->seats,
            'occupied' => $this->occupied,
        ]);

        // Atualize a lista de mesas
        $this->tables = Table::all();

        // Resete os campos e volte para a visualização de lista
        $this->resetFields();
        $this->view = 'list';

        session()->flash('message', 'Table added successfully!');
    }

    public function saveTable()
    {
        if ($this->letter && $this->number) {
            $this->name = $this->letter . '-' . sprintf('%02d', $this->number);
        } else {
            $this->addError('name', 'Both letter and number must be selected to generate the name.');
            return;
        }

        $this->validate();

        Table::updateOrCreate(
            ['name' => $this->name],
            ['seats' => $this->seats, 'occupied' => $this->occupied]
        );

        $this->tables = Table::all();

        // Atualize a visualização para "list"
        $this->view = 'list';

        session()->flash('message', 'Table saved successfully!');
    }


    public function fillTableDetails($id)
    {
        $this->selectedTable = Table::find($id);

        if ($this->selectedTable) {
            $this->letter = substr($this->selectedTable->name, 0, 1);
            $this->number = substr($this->selectedTable->name, 2);
            $this->seats = $this->selectedTable->seats;
            $this->occupied = $this->selectedTable->occupied;
            $this->view = 'edit'; // Exibir o formulário de edição
        } else {
            session()->flash('error', 'Table not found.');
        }
    }

    public function showTableDetails($id)
    {
        $this->selectedTable = Table::find($id);

        // Verifica se o usuário foi encontrado antes de acessar suas propriedades
        if ($this->selectedTable) {
            $this->name = $this->selectedTable->name;
            $this->seats = $this->selectedTable->seats;
            $this->occupied = $this->selectedTable->occupied;

            $this->view = 'details'; // Exibe os detalhes do usuário
        } else {
            session()->flash('error', 'Table not found.');
        }
    }

    public function updateTable()
    {
        if ($this->letter && $this->number) {
            $this->name = $this->letter . '-' . sprintf('%02d', $this->number);
        }
        // Valida os dados do formulário
        $this->validate();

        // Atualiza o usuário selecionado
        $this->selectedTable->update([
            'name' => $this->name,
            'seats' => $this->seats,
            'occupied' => $this->occupied,
        ]);

        // Retorna para a view "list"
        $this->view = 'list';

        // Atualiza a lista de usuários
        $this->tables = Table::all();

        // Exibe uma mensagem de sucesso
        session()->flash('message', 'Table updated successfully!');
    }


    public function resetFields()
    {
        $this->name = '';
        $this->seats = '';
        $this->occupied = '';
        $this->letter = '';
        $this->number = '';
        $this->selectedTable = null;
    }
    public function deleteTable($id)
    {
        Table::find($id)->delete();
        $this->tables = Table::all();
    }

    public function mount()
    {
        $this->tables = Table::all();
    }

    public function render()
    {
        return view('livewire.table-panel', ['view' => $this->view, 'table' => $this->tables, 'selectedTable' => $this->selectedTable])->layout('layouts.admin');
    }
}
