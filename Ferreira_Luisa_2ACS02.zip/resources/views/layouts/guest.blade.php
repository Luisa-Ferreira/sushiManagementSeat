<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>{{ config('app.name', 'Laravel') }}</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        @vite(['resources/css/app.css', 'resources/js/app.js'])

        <!-- Styles -->
        @livewireStyles

        <!-- Alpine.js -->
        <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    </head>
    <body x-data="{ darkMode: {{ session('dark_mode', false) ? 'true' : 'false' }} }"
              x-bind:class="darkMode ? 'bg-gray-900 text-white' : 'bg-white text-black'">
        <!-- Navbar -->
        @include('components.navigation-menu')

        <!-- Page Content -->
        <div class="min-h-screen pt-[4.5rem]">
            <main>
                @yield('content')
            </main>
        </div>

        <!-- Modals -->
        @stack('modals')

        <!-- Livewire Scripts -->
        @livewireScripts
    </body>
</html>
