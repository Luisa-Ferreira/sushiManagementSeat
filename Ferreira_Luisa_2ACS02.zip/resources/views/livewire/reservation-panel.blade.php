<div class="flex flex-col h-screen overflow-hidden">
    <!-- Lista de usuários -->
    @if ($view === 'details')
        <div class="flex-1 bg-[rgb(253,241,225)] text-[rgb(196,151,109)] p-6">
            <div class="px-6 rounded-lg w-3/4 mx-auto">
                <h2 class="text-2xl font-bold mb-2">{{ $selectedReservation->user_id }}</h2>
                <!-- Mostra o e-mail do usuário -->
                <p class="text-sm text-gray-700">Table: {{ $selectedReservation->table_id }}</p>
                <p class="text-sm text-gray-700">Number of People: {{ $selectedReservation->num_people }}</p>
                <p class="text-sm text-gray-700">Reservation Date: {{ $selectedReservation->reservation_date }}</p>
                <p class="text-sm text-gray-700">Reservation Time: {{ $selectedReservation->reservation_time }}</p>

            </div>
        </div>
    @endif


    @if ($view === 'list')
        <h2 class="text-xl  font-bold mb-4">All Reservations</h2>
        <h1 class="mb-6 text-lg">
            <a href="#" wire:click.prevent="showAddReservationForm" class="text-[rgb(196,151,109)] hover:underline">+ Add Reservation</a>
        </h1>
        <ul class="space-y-4 overflow-auto max-h-[70vh] px-2">
            @foreach ($reservations as $reservation)
                <li class="py-3 px-4 border-b border-gray-600 bg-gray-700 rounded-lg">
                    <div class="flex justify-between items-center">
                        <!-- Informações do Usuário -->
                        <div class="w-2/3 truncate">
                            <a href="#" wire:click.prevent="showReservationDetails({{ $reservation->id }})"
                               class="font-bold text-lg text-white">
                                {{ $reservation->user->name }}
                            </a>
                            <p class="text-sm text-gray-300">{{ $reservation->table->name }}</p>
                        </div>
                        <!-- Botões de Ação -->
                        <div class="flex space-x-4">
                            <a href="#" wire:click.prevent="fillReservationDetails({{ $reservation->id }})" class="text-green-500 hover:underline">Change Reservation</a>
                            <a href="#" wire:click.prevent="deleteReservation({{ $reservation->id }})" class="text-red-500 hover:underline">Remove Reservation</a>
                        </div>
                    </div>
                </li>
            @endforeach
        </ul>
    @endif


    <!-- Exibe o formulário para adicionar um novo usuário se a variável $view for 'add' -->
    @if ($view === 'add')
        <h2 class="text-xl font-bold mb-4">Add New Reservation</h2>
        <form wire:submit.prevent="addReservation">
            <div class="mb-4">
                <label class="block text-sm font-medium mb-2">User Name</label>
                <select wire:model="user_id" class="w-full px-4 py-2 border rounded bg-gray-700 text-white">
                    <option value="">Select User...</option>
                    @foreach ($users as $user)
                        <option value="{{ $user->id }}">{{ $user->name }}</option>
                    @endforeach
                </select>
                @error('user_id') <span class="text-red-500 text-sm">{{ $message }}</span> @enderror
            </div>

            <!-- Dropdown para selecionar a Mesa -->
            <div class="mb-4">
                <label class="block text-sm font-medium mb-2">Table</label>
                <select wire:model="table_id" class="w-full px-4 py-2 border rounded bg-gray-700 text-white">
                    <option value="">Select Table...</option>
                    @foreach ($tables as $table)
                        <option value="{{ $table->id }}">{{ $table->name }}</option>
                    @endforeach
                </select>
                @error('table_id') <span class="text-red-500 text-sm">{{ $message }}</span> @enderror
            </div>

            <div class="mb-4">
                <label class="block text-sm font-medium mb-2">Reservation Day</label>
                <input type="date" wire:model="reservation_date" class="w-full px-4 py-2 border rounded bg-gray-700 text-white">
                @error('reservation_date') <span class="text-red-500 text-sm">{{ $message }}</span> @enderror
            </div>

            <div class="mb-4">
                <label class="block text-sm font-medium mb-2">Reservation Time</label>
                <select wire:model="reservation_time" class="w-full px-4 py-2 border rounded bg-gray-700 text-white">
                    <option value="">Select a time...</option>
                    <optgroup label="Lunch">
                        <option value="12:00">12:00</option>
                        <option value="12:30">12:30</option>
                        <option value="13:00">13:00</option>
                        <option value="13:30">13:30</option>
                        <option value="14:00">14:00</option>
                        <option value="14:30">14:30</option>
                        <option value="15:00">15:00</option>
                    </optgroup>
                    <optgroup label="Dinner">
                        <option value="18:00">18:00</option>
                        <option value="18:30">18:30</option>
                        <option value="19:00">19:00</option>
                        <option value="19:30">19:30</option>
                        <option value="20:00">20:00</option>
                        <option value="20:30">20:30</option>
                        <option value="21:00">21:00</option>
                        <option value="21:30">21:30</option>
                        <option value="22:00">22:00</option>
                    </optgroup>
                </select>
                @error('reservation_time') <span class="text-red-500 text-sm">{{ $message }}</span> @enderror
            </div>
            <div class="mb-4">
                <label class="block text-sm font-medium mb-2">Number of People</label>
                <input type="number" wire:model="num_people" class="w-full px-4 py-2 border rounded bg-gray-700 text-white">
                @error('num_people') <span class="text-red-500 text-sm">{{ $message }}</span> @enderror
            </div>
            <button type="submit" class="px-4 py-2 bg-green-500 text-white rounded">Add User</button>
            <button type="button" wire:click.prevent="$set('view', 'list')" class="ml-2 px-4 py-2 bg-gray-500 text-white rounded">Cancel</button>
        </form>
    @endif

    @if ($view === 'edit')
        <h2 class="text-xl font-bold mb-4">Edit User</h2>
        <form wire:submit.prevent="updateReservation">
            <div class="mb-4">
                <label class="block text-sm font-medium mb-2">User Name</label>
                <select wire:model="user_id" class="w-full px-4 py-2 border rounded bg-gray-700 text-white">
                    <option value="">Select User...</option>
                    @foreach ($users as $user)
                        <option value="{{ $user->id }}">{{ $user->name }}</option>
                    @endforeach
                </select>
                @error('user_id') <span class="text-red-500 text-sm">{{ $message }}</span> @enderror
            </div>

            <!-- Dropdown para selecionar a Mesa -->
            <div class="mb-4">
                <label class="block text-sm font-medium mb-2">Table</label>
                <select wire:model="table_id" class="w-full px-4 py-2 border rounded bg-gray-700 text-white">
                    <option value="">Select Table...</option>
                    @foreach ($tables as $table)
                        <option value="{{ $table->id }}">{{ $table->name }}</option>
                    @endforeach
                </select>
                @error('table_id') <span class="text-red-500 text-sm">{{ $message }}</span> @enderror
            </div>

            <div class="mb-4">
                <label class="block text-sm font-medium mb-2">Reservation Day</label>
                <input type="date" wire:model="reservation_date" class="w-full px-4 py-2 border rounded bg-gray-700 text-white">
                @error('reservation_date') <span class="text-red-500 text-sm">{{ $message }}</span> @enderror
            </div>
            <div class="mb-4">
                <label class="block text-sm font-medium mb-2">Reservation Time</label>
                <select wire:model="reservation_time" class="w-full px-4 py-2 border rounded bg-gray-700 text-white">
                    <option value="">Select a time...</option>
                    <optgroup label="Lunch">
                        <option value="12:00">12:00</option>
                        <option value="12:30">12:30</option>
                        <option value="13:00">13:00</option>
                        <option value="13:30">13:30</option>
                        <option value="14:00">14:00</option>
                        <option value="14:30">14:30</option>
                        <option value="15:00">15:00</option>
                    </optgroup>
                    <optgroup label="Dinner">
                        <option value="18:00">18:00</option>
                        <option value="18:30">18:30</option>
                        <option value="19:00">19:00</option>
                        <option value="19:30">19:30</option>
                        <option value="20:00">20:00</option>
                        <option value="20:30">20:30</option>
                        <option value="21:00">21:00</option>
                        <option value="21:30">21:30</option>
                        <option value="22:00">22:00</option>
                    </optgroup>
                </select>
                @error('reservation_time') <span class="text-red-500 text-sm">{{ $message }}</span> @enderror
            </div>
            <div class="mb-4">
                <label class="block text-sm font-medium mb-2">num_people</label>
                <input type="number" wire:model="num_people" class="w-full px-4 py-2 border rounded bg-gray-700 text-white">
                @error('num_people') <span class="text-red-500 text-sm">{{ $message }}</span> @enderror
            </div>
            <button type="submit" class="px-4 py-2 bg-green-500 text-white rounded">Add User</button>
            <button type="button" wire:click.prevent="$set('view', 'list')" class="ml-2 px-4 py-2 bg-gray-500 text-white rounded">Cancel</button>
        </form>
    @endif


</div>
