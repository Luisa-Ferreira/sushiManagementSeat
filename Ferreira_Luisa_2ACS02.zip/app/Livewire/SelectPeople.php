<?php

namespace App\Livewire;

use Livewire\Component;

class SelectPeople extends Component
{
    public $selectedDay;
    public $selectedHour;
    public $peopleCount;

    protected $listeners = ['showPeoplePopup'];

    public function showPeoplePopup($data)
    {
        $this->selectedDay = $data['day'];
        $this->selectedHour = $data['hour'];
        $this->peopleCount = null; // Resetar valor
    }

    public function selectPeople()
    {
        if ($this->peopleCount > 0) {
            $this->dispatch('showTablePopup', [
                'day' => $this->selectedDay,
                'hour' => $this->selectedHour,
                'peopleCount' => $this->peopleCount,
            ]);

            $this->resetPopup();
        }
    }

    public function resetPopup()
    {
        $this->selectedDay = null;
        $this->selectedHour = null;
        $this->peopleCount = null;
    }

    public function render()
    {
        return view('livewire.select-people');
    }
}
