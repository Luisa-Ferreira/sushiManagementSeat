<div class="p-4 bg-[rgb(253,241,225)] rounded">
    <livewire:calendar />
    <livewire:day-popup />
    <livewire:select-people />
    <livewire:select-table />

    <div class="mt-4 text-gray-600">Select a date from the calendar to view available time slots.</div>
</div>
