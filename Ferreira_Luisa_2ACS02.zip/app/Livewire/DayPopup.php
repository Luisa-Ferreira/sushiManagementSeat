<?php

namespace App\Livewire;

use Livewire\Component;

class DayPopup extends Component
{
    public $selectedDay;
    public $availableHours = [];

    protected $listeners = ['daySelected','closePopup'];

    public function selectDay($day)
    {
        $this->dispatch('openPopup', ['selectedDay' => $this->currentDate->format('Y-m') . '-' . $day]);
    }

    public function daySelected($day)
    {
        if (is_array($day)) {
            $day = implode('-', $day); // Combina o array numa string se necessário
        }

        // Certifique-se de que a data está no formato Y-m-d
        $this->selectedDay = date('Y-m-d', strtotime($day));

        // Busca as horas disponíveis para o dia selecionado
        $this->availableHours = $this->getAvailableHours($this->selectedDay);
    }

    private function getAvailableHours($day): array
    {
        try {
            // Certifique-se de que a data fornecida está no formato correto
            $timestamp = strtotime($day);

            if (!$timestamp) {
                throw new \Exception('Formato de data inválido.');
            }

            // Determina o dia da semana (1 = segunda-feira, 7 = domingo)
            $dayOfWeek = date('N', $timestamp);

            // Se for domingo (7), retorna horas vazias
            if ($dayOfWeek == 7) {
                return [];
            }

            // Retorna as horas disponíveis para os outros dias
            return [
                '12:00', '12:30', '13:00', '13:30', '14:00', '14:30', '15:00',
                '18:00', '18:30', '19:00', '19:30', '20:00', '20:30', '21:00', '21:30', '22:00',
            ];
        } catch (\Exception $e) {
            // Lida com erros no formato da data
            return [];
        }
    }

    public function selectHour($hour)
    {
        $this->dispatch('showPeoplePopup', [
            'day' => $this->selectedDay,
            'hour' => $hour,
        ]);
        $this->selectedDay = null;
    }

    public function closePopup()
    {
        $this->selectedDay = null;
        $this->availableHours = [];
    }


    public function render()
    {
        return view('livewire.day-popup')->layout('layouts.app');
    }
}
