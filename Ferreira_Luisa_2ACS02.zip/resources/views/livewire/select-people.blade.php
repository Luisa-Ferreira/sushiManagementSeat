<div>
    @if ($selectedDay && $selectedHour)
        <div
            class="fixed inset-0 bg-gray-500 bg-opacity-50 flex items-center justify-center"
            wire:keydown.escape="resetPopup"
        >
            <div class="bg-white p-4 rounded shadow-lg max-w-md w-full">
                <h2 class="text-lg font-bold mb-2">
                    Select The Number Of People For The Day {{ $selectedDay }} At {{ $selectedHour }}
                </h2>

                <div class="flex justify-center space-x-4 mt-4">
                    <button wire:click="$set('peopleCount', 1)" class="px-4 py-2 bg-blue-500 text-white rounded">1</button>
                    <button wire:click="$set('peopleCount', 2)" class="px-4 py-2 bg-blue-500 text-white rounded">2</button>
                    <button wire:click="$set('peopleCount', 3)" class="px-4 py-2 bg-blue-500 text-white rounded">3</button>
                    <button wire:click="$set('peopleCount', 4)" class="px-4 py-2 bg-blue-500 text-white rounded">4</button>
                    <button wire:click="$set('peopleCount', 5)" class="px-4 py-2 bg-blue-500 text-white rounded">5+</button>
                </div>

                <div class="mt-4 text-center">
                    <button
                        class="px-4 py-2 bg-green-500 text-white rounded"
                        wire:click="selectPeople"
                        {{ $peopleCount ? '' : 'disabled' }}
                    >
                        Confirm
                    </button>
                    <button
                        class="ml-2 px-4 py-2 bg-gray-500 text-white rounded"
                        wire:click="resetPopup"
                    >
                        Cancel
                    </button>
                </div>
            </div>
        </div>
    @endif
</div>
