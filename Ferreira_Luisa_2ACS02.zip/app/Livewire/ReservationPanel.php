<?php

namespace App\Livewire;

use App\Models\Reservation;
use App\Models\Table;
use App\Models\User;
use Livewire\Component;

class ReservationPanel extends Component
{
    public $view = 'list';
    public $reservations = [];
    public $users = [];
    public $tables = [];
    public $user_id,$table_id,$num_people,$reservation_date,$reservation_time;
    public $selectedReservation;
    protected $listeners = ['resetReservationPanel','showAddReservationForm', 'showReservationDetails' ];

    protected $rules = [
        'user_id' => 'required|exists:users,id',
        'table_id' => 'required|exists:tables,id',
        'reservation_date' => 'required|date_format:Y-m-d',
        //time that the restaurante is open
        'reservation_time' => 'required|date_format:H:i|in:12:00,12:30,13:00,13:30,14:00,14:30,15:00,18:00,18:30,19:00,19:30,20:00,20:30,21:00,21:30,22:00',
        'num_people' => 'required|integer|min:1'
    ];

    protected $messages = [
        'reservation_time.in' => 'The reservation time must be within the allowed intervals.',
        'user_id.required' => 'Please select a user for the reservation.',
        'table_id.required' => 'Please select a table for the reservation.',
        'reservation_date.required' => 'Please select a reservation date.',
        'num_people.required' => 'Please specify the number of people.',
    ];

    public function showAddReservationForm()
    {
        //to reset the previus data insert
        $this->resetFields();
        $this->view = 'add';
    }
    public function addReservation()
    {

        $this->validate();
        //to check if exists any reservation for that place
        $conflict = Reservation::where('table_id', $this->table_id)
            ->where('reservation_date', $this->reservation_date)
            ->where('reservation_time', $this->reservation_time)
            ->exists();

        if ($conflict) {
            session()->flash('error', 'This table is already reserved for the selected date and time.');
            return;
        }
        Reservation::create([
            'user_id' => $this->user_id,
            'table_id' => $this->table_id,
            'reservation_date' => $this->reservation_date,
            'reservation_time' => $this->reservation_time,
            'num_people' => $this->num_people,
        ]);

        session()->flash('message', 'Reservation added successfully!');
        $this->reset(); // Limpa os campos
        $this->reservations = Reservation::all();
        // Atualiza a lista (se necessário)
        $this->view = 'list';
    }

    public function fillReservationDetails($id)
    {
        $this->selectedReservation = Reservation::find($id);

        // Preencha as propriedades com os valores do usuário selecionado
        $this->user_id = $this->selectedReservation->user_id;
        $this->table_id = $this->selectedReservation->table_id;
        $this->num_people = $this->selectedReservation->num_people;
        $this->reservation_date = $this->selectedReservation->reservation_date;
        $this->reservation_time = $this->selectedReservation->reservation_time;

        $this->users = User::all();
        $this->tables = Table::all();

        $this->view = 'edit'; // Exibe o formulário de edição
    }
    public function showReservationDetails($id)
    {
        $this->selectedReservation = Reservation::find($id);

        // Verifica se o usuário foi encontrado antes de acessar suas propriedades
        if ($this->selectedReservation) {
            $this->user_id = $this->selectedReservation->user_id;
            $this->table_id = $this->selectedReservation->table_id;
            $this->num_people = $this->selectedReservation->num_people;
            $this->reservation_date = $this->selectedReservation->reservation_date;
            $this->reservation_time = $this->selectedReservation->reservation_time;

            $this->view = 'details'; // Exibe os detalhes do usuário
        } else {
            session()->flash('error', 'Table not found.');
        }
    }

    public function updateReservation()
    {
        $this->reservation_date = \Carbon\Carbon::parse($this->reservation_date)->format('Y-m-d');


        // Valida os dados do formulário
        $this->validate();

        $conflict = Reservation::where('table_id', $this->table_id)
            ->where('reservation_date', $this->reservation_date)
            ->where('reservation_time', $this->reservation_time)
            ->where('id', '!=', $this->selectedReservation->id) // Ignora a reserva atual
            ->exists();

        if ($conflict) {
            session()->flash('error', 'This table is already reserved for the selected date and time.');
            return;
        }

        // Atualiza o usuário selecionado
        $this->selectedReservation->update([
            'user_id' => $this->user_id,
            'table_id' => $this->table_id,
            'num_people' => $this->num_people,
            'reservation_date' => $this->reservation_date,
            'reservation_time' => $this->reservation_time
        ]);



        // Atualiza a lista de usuários
        $this->reservations = Reservation::all();

        // Exibe uma mensagem de sucesso
        session()->flash('message', 'Table updated successfully!');

        // Retorna para a view "list"
        $this->view = 'list';
    }


    public function resetFields()
    {
        $this->user_id = '';
        $this->table_id = '';
        $this->num_people = '';
        $this->reservation_date = '';
        $this->reservation_time = '';

        $this->selectedReservation = null;
    }
    public function deleteReservation($id)
    {
        Reservation::find($id)->delete();
        $this->reservations = Reservation::all();
    }

    public function mount()
    {
        $this->users = User::all(); // Carrega todos os usuários
        $this->tables = Table::all();
        $this->reservations = Reservation::all();
    }

    public function render()
    {
        return view('livewire.reservation-panel', ['view' => $this->view, 'reservation' => $this->reservations, 'selectedReservation' => $this->selectedReservation])->layout('layouts.admin');
    }
}
