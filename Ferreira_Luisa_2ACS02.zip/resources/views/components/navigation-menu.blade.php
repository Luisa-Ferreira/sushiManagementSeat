<nav class="bg-gray-800 text-white shadow-lg fixed top-0 left-0 right-0 z-50">
    <div class="container mx-auto px-4 py-4 flex justify-between items-center">
        <!-- Logo -->
        <a href="/" class="flex items-center">
            <img src="{{ asset('images/logo.png') }}" alt="SushiAway Logo" class="h-16">
            <span class="ml-3 text-xl font-semibold">SushiAway</span>
        </a>

        <button
            @click="darkMode = !darkMode; $dispatch('theme-toggled', darkMode)"
            class="px-4 py-2 rounded bg-yellow-500 hover:bg-yellow-600 text-black"
        >
            <span x-text="darkMode ? 'Light Mode' : 'Dark Mode'"></span>
        </button>

        <!-- Links -->
        <div class="hidden md:flex space-x-6">

            <a href="/" class=" py-2 hover:text-yellow-400">Home</a>
            <a href="#location" class=" py-2 hover:text-yellow-400">Location</a>
            <a href="#contact" class=" py-2 hover:text-yellow-400">Contact</a>

            @auth
                <!-- Exibe o nome do usuário logado -->
                <div class="flex items-center space-x-4">
                    <span class="text-yellow-400">Welcome, {{ auth()->user()->name }}!</span>
                    <form method="POST" action="{{ route('logout') }}">
                        @csrf
                        <button type="submit" class="ml-4 px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600">
                            Logout
                        </button>
                    </form>
                </div>
            @else
                <!-- Link para login se não estiver logado -->
                <a href="{{ route('login') }}" class="ml-4 px-4 py-2 bg-yellow-500 text-white rounded hover:bg-yellow-600">
                    {{ __('Login') }}
                </a>
            @endauth

        </div>
    </div>
</nav>
