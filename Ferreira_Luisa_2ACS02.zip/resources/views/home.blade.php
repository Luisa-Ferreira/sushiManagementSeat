@extends('layouts.guest')

@section('content')
    <!-- Hero Section -->
    <section id="home"
             class="relative h-screen flex items-center justify-center"
             x-bind:class="darkMode ? 'bg-[rgb(180,12,40)] text-[rgb(220,220,220)]' : 'bg-[rgb(230,16,50)] text-[rgb(253,241,225)]'">
        <div class="z-20 text-center">
            <h1 class="text-4xl md:text-6xl font-bold">Welcome to SushiAway!</h1>
            <p class="mt-4 text-lg">SushiAway, on the way, bringing sushi night and day!</p>
        </div>
    </section>

    <!-- Reservation Section -->
    <section id="reservation"
             class="relative h-screen flex items-center justify-center"
             x-bind:class="darkMode ? 'bg-[rgb(40,40,40)] text-[rgb(200,50,70)]' : 'bg-white text-[rgb(230,16,50)]'">
        <div class="container mx-auto text-center">
            <h2 class="text-3xl font-semibold mb-6">Mark Your seat below!</h2>
            <a href="/nowReservations"
               class="ml-4 px-4 py-2 bg-yellow-500 text-white rounded hover:bg-yellow-600">
                Now In the Restaurant
            </a>
            <a href="/futureReservations"
               class="ml-4 px-4 py-2 bg-yellow-500 text-white rounded hover:bg-yellow-600">
                Reservations
            </a>
        </div>
    </section>

    <!-- Location Section -->
    <section id="location"
             class="relative h-screen flex items-center justify-center"
             x-bind:class="darkMode ? 'bg-[rgb(60,30,30)] text-[rgb(230,200,200)]' : 'bg-[rgb(253,241,225)] text-[rgb(230,16,50)]'">
        <div class="container mx-auto text-center">
            <h2 class="text-3xl font-semibold mb-6">Find Us</h2>
            <p class="mb-4">We are located in the heart of the city.</p>
            <div class="w-full h-64">
                <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3123.1365585561034!2d-9.1647381!3d38.7169918!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd193366d6c4dc7b%3A0x47a4bbecfd0df635!2sSushi-Away!5e0!3m2!1sen!2sus!4v1695224977082!5m2!1sen!2sus"
                    width="100%"
                    height="100%"
                    style="border:0;"
                    allowfullscreen=""
                    loading="lazy">
                </iframe>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    @include('components.footer')

@endsection
