<div class="flex flex-col h-screen overflow-hidden">
    <!-- Lista de usuários -->
    @if ($view === 'details')
        <div class="flex-1 bg-[rgb(253,241,225)] text-[rgb(196,151,109)] p-6">
            <div class="px-6 rounded-lg w-3/4 mx-auto">
                <h2 class="text-2xl font-bold mb-2">{{ $selectedUser->name }}</h2>
                <!-- Mostra o e-mail do usuário -->
                <p class="text-sm text-gray-700">Email: {{ $selectedUser->email }}</p>
                <!-- Mostra a data de criação do usuário -->
                <p class="text-sm text-gray-700">Created at: {{ $selectedUser->created_at }}</p>
            </div>
        </div>
    @endif

    @if ($view === 'list')
        <h2 class="text-xl  font-bold mb-4">All Users</h2>
        <h1 class="mb-6 text-lg">
            <a href="#" wire:click.prevent="showAddUserForm" class="text-[rgb(196,151,109)] hover:underline">+ Add User</a>
        </h1>

        <div class="flex flex-col md:flex-row md:space-x-4 mb-6">
            <!-- Search -->
            <div class="w-full md:w-1/2 mb-4 md:mb-0">
                <input
                    type="text"
                    wire:model.live="search"
                    placeholder="Search by name, email or phone..."
                    class="w-full px-4 py-2 border rounded bg-gray-700 text-white"
                />
            </div>

            <!-- Filter by Role -->
            <div class="w-full md:w-1/4">
                <select
                    wire:model.live="filterRole"
                    class="w-full px-4 py-2 border rounded bg-gray-700 text-white"
                >
                    <option value="">All Roles</option>
                    <option value="manager">Manager</option>
                    <option value="employee">Employee</option>
                    <option value="client">Client</option>
                </select>
            </div>
        </div>


        <ul class="space-y-4 overflow-auto max-h-[70vh] px-2">
            @foreach ($users as $user)
                <li class="py-3 px-4 border-b border-gray-600 bg-gray-700 rounded-lg">
                    <div class="flex justify-between items-center">
                        <!-- Informações do Usuário -->
                        <div class="w-2/3 truncate">
                            <a href="#" wire:click.prevent="showUserDetails({{ $user->id }})" class="font-bold text-lg text-white">{{ $user->name }}</a>
                            <p class="text-sm text-gray-300">{{ $user->phone }}</p>
                        </div>
                        <!-- Botões de Ação -->
                        <div class="flex space-x-4">
                            <a href="#" wire:click.prevent="fillUserDetails({{ $user->id }})" class="text-green-500 hover:underline">Change User</a>

                            <div x-data="{ showRemoveModal: false }">
                                <a href="#" @click="showRemoveModal = true" class="text-red-500 hover:underline">Remove User</a>

                                <div x-show="showRemoveModal" x-transition.opacity class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
                                    <div class="bg-white p-6 rounded shadow-lg w-1/3">
                                        <h2 class="text-2xl font-bold mb-4">Delete Confirmation</h2>
                                        <p class="mb-6">Do you really want to delete this user?</p>
                                        <div class="flex justify-end space-x-4">
                                            <button @click="showRemoveModal = false; $wire.set('view', 'list')" class="px-4 py-2 bg-gray-500 text-white rounded">Cancel</button>
                                            <button @click="showRemoveModal = false; $wire.deleteUser({{ $user->id }})" class="px-4 py-2 bg-red-500 text-white rounded">Remove</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
            @endforeach
        </ul>
    @endif

    <div x-data="{ showAddModal: false, showEditModal: false }">
        <div @add-user-modal.window="showAddModal = true; setTimeout(() => { showAddModal = false; $wire.set('view', 'list'); }, 10000)">
            @if ($view === 'add')
                <h2 class="text-xl font-bold mb-4">Add New User</h2>
                <form wire:submit.prevent="addUser">
                    <div class="mb-4">
                        <label class="block text-sm font-medium mb-2">Name</label>
                        <input type="text" wire:model="name" class="w-full px-4 py-2 border rounded bg-gray-700 text-white">
                        @error('name') <span class="text-red-500 text-sm">{{ $message }}</span> @enderror
                    </div>
                    <div class="mb-4">
                        <label class="block text-sm font-medium mb-2">Email</label>
                        <input type="email" wire:model="email" class="w-full px-4 py-2 border rounded bg-gray-700 text-white">
                        @error('email') <span class="text-red-500 text-sm">{{ $message }}</span> @enderror
                    </div>
                    <div class="mb-4">
                        <label class="block text-sm font-medium mb-2">Phone</label>
                        <input type="text" wire:model="phone" class="w-full px-4 py-2 border rounded bg-gray-700 text-white">
                        @error('phone') <span class="text-red-500 text-sm">{{ $message }}</span> @enderror
                    </div>
                    <div class="mb-4">
                        <label class="block text-sm font-medium mb-2">Password</label>
                        <input type="password" wire:model="password" class="w-full px-4 py-2 border rounded bg-gray-700 text-white">
                        @error('password') <span class="text-red-500 text-sm">{{ $message }}</span> @enderror
                    </div>
                    <div class="mb-4">
                        <label class="block text-sm font-medium mb-2">Role</label>
                        <select wire:model="role" class="w-full px-4 py-2 border rounded bg-gray-700 text-white">
                            <option value="">Select Role</option>
                            <option value="manager">Manager</option>
                            <option value="employee">Employee</option>
                            <option value="client">Client</option>
                        </select>
                        @error('role') <span class="text-red-500 text-sm">{{ $message }}</span> @enderror
                    </div>
                    <button type="submit" class="px-4 py-2 bg-green-500 text-white rounded">Add User</button>
                    <button type="button" wire:click.prevent="$set('view', 'list')" class="ml-2 px-4 py-2 bg-gray-500 text-white rounded">Cancel</button>
                </form>
            @endif

            <div x-show="showAddModal" x-transition.opacity class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
                <div class="bg-white p-6 rounded shadow-lg w-1/3">
                    <h2 class="text-2xl font-bold mb-4">User Added Successfully</h2>
                    <p class="mb-6">The user has been added to the system.</p>
                    <div class="flex justify-end">
                        <button @click="showAddModal = false; $wire.set('view', 'list')" class="px-4 py-2 bg-green-500 text-white rounded">OK</button>
                    </div>
                </div>
            </div>
        </div>

        <div @edit-user-modal.window="showEditModal = true; setTimeout(() => { showEditModal = false; $wire.set('view', 'list'); }, 10000)">

            @if ($view === 'edit')

                <h2 class="text-xl font-bold mb-4">Edit User</h2>
                <form wire:submit.prevent="updateUser">
                    <div class="mb-4">
                        <label class="block text-sm font-medium mb-2">Name</label>
                        <input type="text" wire:model="name" class="w-full px-4 py-2 border rounded bg-gray-700 text-white">
                        @error('name') <span class=" text-sm">{{ $message }}</span> @enderror
                    </div>
                    <div class="mb-4">
                        <label class="block text-sm font-medium mb-2">Email</label>
                        <input type="email" wire:model="email" class="w-full px-4 py-2 border rounded bg-gray-700 text-white">
                        @error('email') <span class=" text-sm">{{ $message }}</span> @enderror
                    </div>
                    <div class="mb-4">
                        <label class="block text-sm font-medium mb-2">Phone</label>
                        <input type="text" wire:model="phone" class="w-full px-4 py-2 border rounded bg-gray-700 text-white">
                        @error('phone') <span class=" text-sm">{{ $message }}</span> @enderror

                    </div>
                    <div class="mb-4">
                        <label class="block text-sm font-medium mb-2">Password</label>
                        <input type="text" wire:model="password" class="w-full px-4 py-2 border rounded bg-gray-700 text-white">
                        @error('password') <span class=" text-sm">{{ $message }}</span> @enderror

                    </div>
                    <div class="mb-4">
                        <label class="block text-sm font-medium mb-2">Role</label>
                        <select wire:model="role"
                                class="w-full px-4 py-2 border rounded bg-gray-700 text-white">
                            <option value="">Select Role</option>
                            <option value="manager">Manager</option>
                            <option value="employee">Employee</option>
                            <option value="client">Client</option>
                        </select>
                        @error('role') <span class="text-red-500 text-sm">{{ $message }}</span> @enderror
                    </div>

                    <button type="submit" class="px-4 py-2 bg-blue-500 text-white rounded">Save Changes</button>
                    <button type="button" wire:click.prevent="$set('view', 'list')" class="ml-2 px-4 py-2 bg-gray-500 text-white rounded">Cancel</button>
                </form>
                <div x-show="showEditModal" x-transition.opacity class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
                    <div class="bg-white p-6 rounded shadow-lg w-1/3">
                        <h2 class="text-2xl font-bold mb-4">User Changed Successfully</h2>
                        <p class="mb-6">The user has been changed in the system.</p>
                        <div class="flex justify-end">
                            <button @click="showEditModal = false; $wire.set('view', 'list')" class="px-4 py-2 bg-green-500 text-white rounded">OK</button>
                        </div>
                    </div>
                </div>
            @endif
        </div>
    </div>
</div>
