<?php

namespace App\Http;

use App\Http\Middleware\EmployeeMiddleware;
use App\Http\Middleware\IsManager;
use Illuminate\Auth\Middleware\Authenticate;
use Illuminate\Foundation\Http\Kernel as HttpKernel;

class Kernel extends HttpKernel
{


    /**
     * The application's route middleware.
     *
     * @var array
     */
    protected $routeMiddleware = [
        // Outros middlewares
        'IsManager' =>IsManager::class, // Certifique-se de que está adicionado aqui
        'employee' => EmployeeMiddleware::class,
    ];
}
