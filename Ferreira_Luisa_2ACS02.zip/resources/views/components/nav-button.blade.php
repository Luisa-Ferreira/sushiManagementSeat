<form method="{{ $method ?? 'GET' }}" action="{{ $action }}" class="inline-block">
    @csrf
    <button type="submit" class="px-4 py-2 {{ $class ?? '' }}">
        {{ $label }}
    </button>
</form>
