<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Page</title>

    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="text-white h-screen flex flex-col">
<!-- Header -->
<header class="bg-red-500 p-6 flex justify-between items-center">
    <h1 class="text-xl font-bold">Sushi Away Admin Panel</h1>
    <div class="flex items-center space-x-4">
        <span>Welcome, {{ auth()->user()->name }}</span>
        <a href="/" class="text-white font-bold hover:underline">View Site</a>
        <form method="POST" action="{{ route('logout') }}" class="inline">
            @csrf
            <button type="submit" class="text-white font-bold hover:underline">Log Out</button>
        </form>
    </div>
</header>

<!-- Main Layout -->
<div class="flex flex-1 h-full">
    <aside class="bg-[rgb(196,151,109)] text-white w-48 p-4 h-full flex-shrink-0">
        <ul class="space-y-4">
            <li>
                <a href="{{ route('users') }}" class="text-white font-bold hover:underline">Users</a>
            </li>
            <li>
                <a href="{{ route('tables') }}" class="text-white font-bold hover:underline">Tables</a>
            </li>
            <li>
                <a href="{{ route('reservations') }}" class="text-white font-bold hover:underline">Reservations</a>
            </li>
        </ul>
    </aside>
    <!-- Main Content -->
    <main class="flex-1 bg-[rgb(253,241,225)] text-[rgb(196,151,109)] p-6 h-screen w-full">
        <!-- Slot for Sidebar and Main Content -->
        {{ $slot }}
    </main>
</div>
</body>
</html>
