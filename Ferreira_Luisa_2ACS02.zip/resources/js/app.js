import './bootstrap';

document.addEventListener('alpine:init', () => {
    Alpine.data('themeToggler', () => ({
        toggleTheme(isDarkMode) {
            fetch('/theme', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                },
                body: JSON.stringify({ darkMode: isDarkMode }),
            });
        },
    }));
});
