<?php

namespace App\Livewire;

use App\Models\User;
use Livewire\Component;

class SearchFilter extends Component
{
    public $search = ''; // Para a busca pelo nome
    public $role = '';   // Para o filtro por role
    public $users = [];  // Lista de usuários filtrados

    protected $queryString = ['search', 'role']; // Sincroniza os parâmetros na URL

    public function updated($field)
    {
        // Atualiza os resultados ao alterar os campos de busca ou filtro
        if ($field === 'search' || $field === 'role') {
            $this->filterUsers();
        }
    }

    public function filterUsers()
    {
        $query = User::query();

        // Aplica busca pelo nome
        if (!empty($this->search)) {
            $query->where('name', 'like', '%' . $this->search . '%');
        }

        // Aplica filtro pelo role
        if (!empty($this->role)) {
            $query->where('role', $this->role);
        }

        $this->users = $query->get();
    }

    public function mount()
    {
        $this->filterUsers(); // Filtra os usuários na inicialização
    }

    public function render()
    {
        return view('livewire.search-filter', [
            'roles' => ['manager', 'employee', 'client'], // Lista de roles
        ]);
    }
}
