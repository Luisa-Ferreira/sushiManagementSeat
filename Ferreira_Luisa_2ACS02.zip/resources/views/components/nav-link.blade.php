<a href="{{ $href }}" class="py-2 hover:text-yellow-400 {{ $class ?? '' }}">
    {{ $text }}
</a>
